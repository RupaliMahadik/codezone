
// @author: Tatiana Williamson
// @description: UO1 Version-1.1.
// @Date: 8th Mar 2018.

function setNavItemAsCurrent(itemText) {
    $('.nav > li > a').each(function() {
        if($(this).text().indexOf(itemText) >= 0) {
            $(this).parent().addClass('current');
        }
    });
}

$(document).ready(function(){
    var url = window.location.pathname;
    var fullFilename = url.substring(url.lastIndexOf('/')+1);
    var filename = fullFilename.substring(0, fullFilename.lastIndexOf('.'));
    var navItemText = filename.replace('_', ' ').toUpperCase();
    //alert(navItemText);
    if(navItemText == 'INDEX') {
        navItemText = 'HOME';
    } else if(navItemText == 'GLYCAN SEARCHPAGE') {
        navItemText = 'EXPLORE';
    } else if(navItemText == 'PROTEIN SEARCHPAGE') {
        navItemText = 'EXPLORE';
    } else if(navItemText == 'GLYCOPROTEIN SEARCHPAGE') {
        navItemText = 'EXPLORE';
    } else if(navItemText == 'ABOUT') {
        navItemText = 'ABOUT';
    } else if(navItemText == 'RESOURCES') {
        navItemText = 'MORE';
    } else if(navItemText == 'SURVEY') {
        navItemText = 'MORE';
    } else if(navItemText == 'CONTACT') {
        navItemText = 'MORE';
    } else if(navItemText == 'GLYGEN SETTINGS') {
        navItemText = 'MY GLYGEN';
    }
  
    $('.nav > li').removeClass('current');
    setNavItemAsCurrent(navItemText);
});

// End @author: Tatiana Williamson
